import java.util.Scanner;

/**
        * Explicació
        *
        * @author
* Data
        *
        */

public class Practica4 {
    public static void main(String[] args) {
        System.out.println("****************************************");
        System.out.println("Test Pràctica 4");
        System.out.println("****************************************");
        Scanner input = new Scanner(System.in);
        System.out.println("Entra un nombre");
        int number1 = input.nextInt();
        System.out.println("Entra un altre nombre");
        int number2 = input.nextInt();


        Calculadora calc = new Calculadora();

        System.out.println("La suma de " + number1 + " i " + number2 + " és " + calc.sum(number1, number2));
        System.out.println("El producte de " + number1 + " i " + number2 + " és " + calc.producte(number1, number2));
        System.out.println("La resta de " + number1 + " i " + number2 + " és " + calc.resta(number1, number2));
        System.out.println("La divisió de " + number1 + " i " + number2 + " és " + calc.divisio(number1, number2));


        input.close();
    }
}