/**
 *
 * Explicació
 *
 * @author
 * Data
 *
 */

public class Calculadora {

    /**
     * Explicació constructor
     * @param x
     * @param y
     * @return
     */
    public Calculadora () {
    }

    /**
     * Explicació mètode
     * @param x
     * @param y
     * @return
     */
    public int sum(int x, int y) {
        return x+y;
    }


    /**
     *
     * @param x
     * @param y
     * @return
     */
    public int resta(int x, int y) {
        return x-y;
    }


    /**
     *
     * @param x
     * @param y
     * @return
     */
    public int producte(int x, int y) {
        return x*y;
    }


    /**
     *
     * @param x
     * @param y
     * @return
     */
    public double divisio(int x, int y) {
        try {
            return x / y;
        } catch (ArithmeticException e) {
            System.out.println("No es pot dividir per zero");
            return 0;
        }
    }
}
